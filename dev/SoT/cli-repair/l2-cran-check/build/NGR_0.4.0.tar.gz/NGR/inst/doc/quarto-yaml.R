## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(NGR)

work <- file.path(tempdir(), "ngr-quarto-yaml-vignette")
unlink(work, recursive = TRUE, force = TRUE)
dir.create(file.path(work, "yml"), recursive = TRUE)
dir.create(file.path(work, "_chapters"), recursive = TRUE)
dir.create(file.path(work, "bib"), recursive = TRUE)

manifest_path <- file.path(work, "report.qmd")
base_path <- file.path(work, "yml", "_quarto.yml")

writeLines(c(
  "---",
  "title: Example Report",
  "chapters:",
  "  - _chapters/intro.qmd",
  "bibliography: bib/references.bib",
  "---",
  "",
  "# Body"
), manifest_path)

writeLines(c(
  "project:",
  "  type: default",
  "  preview: false",
  "execute:",
  "  echo: true",
  "format:",
  "  html:",
  "    toc: true"
), base_path)

frontmatter <- quartoReadFrontmatter(manifest_path)
base <- yaml::read_yaml(base_path)
book_config <- quartoMergeBookManifest(base, frontmatter)

cat(quartoAsYaml(book_config))

## -----------------------------------------------------------------------------
single_file_config <- quartoSetProjectRender(base, "report.qmd")
cat(quartoAsYaml(single_file_config))

## -----------------------------------------------------------------------------
docx_profile <- list(format = list(docx = list(toc = TRUE, `number-sections` = FALSE)))
docx_book_profile <- quartoDocxBookProfile(docx_profile)
cat(quartoAsYaml(docx_book_profile))

