## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", eval = FALSE)

## ----line-point-data----------------------------------------------------------
# library(NGR)
# library(data.table)
# 
# DataLines <- data.table(
#   ID = rep(c("A", "B", "C"), each = 5),
#   X = as.numeric(rep(1:5, 3)),
#   Y = as.numeric(c(seq(1, 5), seq(2, 6), seq(3, 7))),
#   style = c(rep("solid", 5), rep("dotted", 5), rep("dashed", 5)),
#   fill = c(rep(TRUE, 5), rep(TRUE, 5), rep(FALSE, 5))
# )
# 
# DataPoints <- data.table(
#   ID = rep(c("A", "B", "C"), each = 4),
#   X = as.numeric(rep(1:4, 3)),
#   Y = as.numeric(c(seq(8, 11), seq(6, 9), seq(4, 7))),
#   style = c(rep("circle", 4), rep("diamond", 4), rep("triangle-down", 4))
# )

## ----combined-plot------------------------------------------------------------
# PLOT <- buildPlot(
#   data.lines = DataLines,
#   data.points = DataPoints,
#   line.type = "spline",
#   plot.title = "Combined Lines and Points Example",
#   plot.subtitle = "Demonstration of fills, line styles, and point styles",
#   plot.height = 500,
#   plot.width = 700,
#   xAxis.legend = "Time (units)",
#   yAxis.legend = "Value",
#   print.max.abs = FALSE
# )
# 
# PLOT

