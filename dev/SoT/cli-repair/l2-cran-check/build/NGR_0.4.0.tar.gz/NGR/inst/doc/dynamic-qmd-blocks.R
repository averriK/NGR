## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----example------------------------------------------------------------------
library(NGR)

Root <- file.path(tempdir(), "ngr-knit-block-vignette")
unlink(Root, recursive = TRUE, force = TRUE)
dir.create(file.path(Root, "_tbl"), recursive = TRUE)

writeLines(c(
  "```{r}",
  "#| label: tbl-site-view",
  "#| tbl-cap: \"Internal site/model view\"",
  "knitr::kable(data.frame(site = siteID_TARGET, model = ID_TARGET))",
  "```"
), file.path(Root, "_tbl", "site.qmd"))

writeLines(c(
  "{{< include /_tbl/site.qmd >}}",
  "",
  "```{r}",
  "#| label: tbl-hazard-summary",
  "#| tbl-cap: !expr CAP",
  "knitr::kable(data.frame(site = siteID_TARGET, model = ID_TARGET, value = VALUE))",
  "```"
), file.path(Root, "_tbl", "hazard.qmd"))

## -----------------------------------------------------------------------------
knitr::kable(data.frame(site = siteID_TARGET, model = ID_TARGET))

## -----------------------------------------------------------------------------
knitr::kable(data.frame(site = siteID_TARGET, model = ID_TARGET, value = VALUE))

## -----------------------------------------------------------------------------
knitr::kable(data.frame(site = siteID_TARGET, model = ID_TARGET))

## -----------------------------------------------------------------------------
knitr::kable(data.frame(site = siteID_TARGET, model = ID_TARGET, value = VALUE))

## ----repeated-calls, results = "asis"-----------------------------------------
knitBlock(
  path = "/_tbl/hazard.qmd",
  stem = "site-a-model-1",
  vars = list(
    siteID_TARGET = "SITE_A",
    ID_TARGET = "MODEL_1",
    VALUE = 0.42,
    CAP = "Hazard summary for SITE_A / MODEL_1."
  ),
  root = Root
)

knitBlock(
  path = "/_tbl/hazard.qmd",
  stem = "site-b-model-2",
  vars = list(
    siteID_TARGET = "SITE_B",
    ID_TARGET = "MODEL_2",
    VALUE = 0.67,
    CAP = "Hazard summary for SITE_B / MODEL_2."
  ),
  root = Root
)

